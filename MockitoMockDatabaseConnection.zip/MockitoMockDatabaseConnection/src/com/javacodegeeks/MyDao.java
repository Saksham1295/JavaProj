package com.javacodegeeks;

public class MyDao {
	
	public MyEntity findById(long id) {
		
		throw new UnsupportedOperationException();
	}

}
